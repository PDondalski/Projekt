SELECT
	  IDKlient
    , Nazwa
FROM
	zakupy z
    RIGHT JOIN
    klienci k
		ON z.KlientID = k.IDKlient
WHERE
	z.IDZakup IS NULL;