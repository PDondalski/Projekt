SELECT
	 p.Imie
    , p.nazwisko
    , f.FunkcjaNazwa
FROM
	pracownicy p
    INNER JOIN
    funkcjepracownikow f
		ON p.FunkcjaID = f.IDFunkcja;