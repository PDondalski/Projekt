SELECT
	Album
    , SUM(wartość) AS sumaWartosci
FROM
	zakupywszystko
GROUP BY
	Album
ORDER BY
	sumaWartosci DESC;

