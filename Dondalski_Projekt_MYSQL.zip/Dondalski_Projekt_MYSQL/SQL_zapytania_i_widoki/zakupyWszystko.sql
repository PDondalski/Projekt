SELECT
	  z.DataZakupu `data zakupu`
    , CONCAT(p.Imie, ' ', p.Nazwisko) `Imię i nazwisko pracownika`
    , fp.FunkcjaNazwa `funkcja pracownika`
    , k.Nazwa `nazwa klienta`
    , k.NIP `NIP klienta`
    , k.KodPoczt `kod pocztowy`
    , k.Miasto
    , k.UlicaNr `ulica, nr`
    , kt.Kategoria
    , pr.Wykonawca
    , pr.Album
    , g.Gatunek
    , z.Ilosc `ilość`
    , ROUND(pr.Cena, 2) `cena`
    , ROUND(z.Ilosc * pr.Cena, 2) AS `wartość`
   
FROM
	zakupy z    LEFT JOIN
    (
		pracownicy p
		INNER JOIN
		funkcjepracownikow fp
			ON p.FunkcjaID = fp.IDFunkcja
	) ON z.PracownikID = p.IDPracownik
	INNER JOIN
    klienci k
		ON z.KlientID = k.IDKlient
	INNER JOIN
    produkty pr
		ON z.ProduktID = pr.IDProdukt
	INNER JOIN
	kategorie kt
		ON pr.KategoriaID = kt.IDKategoria
	LEFT JOIN
	gatunki g
		ON pr.GatunekID = g.IDGatunek;