-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: musicshop
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `zakupypracownikow3plus`
--

DROP TABLE IF EXISTS `zakupypracownikow3plus`;
/*!50001 DROP VIEW IF EXISTS `zakupypracownikow3plus`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `zakupypracownikow3plus` AS SELECT 
 1 AS `data zakupu`,
 1 AS `Imię i nazwisko pracownika`,
 1 AS `IDPracownik`,
 1 AS `funkcja pracownika`,
 1 AS `nazwa klienta`,
 1 AS `NIP klienta`,
 1 AS `kod pocztowy`,
 1 AS `Miasto`,
 1 AS `ulica, nr`,
 1 AS `Kategoria`,
 1 AS `Wykonawca`,
 1 AS `Album`,
 1 AS `Gatunek`,
 1 AS `ilość`,
 1 AS `cena`,
 1 AS `wartość`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `gatunkiwartosci`
--

DROP TABLE IF EXISTS `gatunkiwartosci`;
/*!50001 DROP VIEW IF EXISTS `gatunkiwartosci`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `gatunkiwartosci` AS SELECT 
 1 AS `Gatunek`,
 1 AS `sumaWartosci`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `pracownicybezsprzedazy`
--

DROP TABLE IF EXISTS `pracownicybezsprzedazy`;
/*!50001 DROP VIEW IF EXISTS `pracownicybezsprzedazy`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `pracownicybezsprzedazy` AS SELECT 
 1 AS `Imie`,
 1 AS `Nazwisko`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `produktywszystko`
--

DROP TABLE IF EXISTS `produktywszystko`;
/*!50001 DROP VIEW IF EXISTS `produktywszystko`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `produktywszystko` AS SELECT 
 1 AS `Wykonawca`,
 1 AS `Album`,
 1 AS `DataPremiery`,
 1 AS `Cena`,
 1 AS `Kategoria`,
 1 AS `Gatunek`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `klienciliczbazakupow`
--

DROP TABLE IF EXISTS `klienciliczbazakupow`;
/*!50001 DROP VIEW IF EXISTS `klienciliczbazakupow`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `klienciliczbazakupow` AS SELECT 
 1 AS `nazwa klienta`,
 1 AS `LiczbaZakupow`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `zakupywszystko`
--

DROP TABLE IF EXISTS `zakupywszystko`;
/*!50001 DROP VIEW IF EXISTS `zakupywszystko`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `zakupywszystko` AS SELECT 
 1 AS `data zakupu`,
 1 AS `Imię i nazwisko pracownika`,
 1 AS `IDPracownik`,
 1 AS `funkcja pracownika`,
 1 AS `nazwa klienta`,
 1 AS `NIP klienta`,
 1 AS `kod pocztowy`,
 1 AS `Miasto`,
 1 AS `ulica, nr`,
 1 AS `Kategoria`,
 1 AS `Wykonawca`,
 1 AS `Album`,
 1 AS `Gatunek`,
 1 AS `ilość`,
 1 AS `cena`,
 1 AS `wartość`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `kliencibezzakupow`
--

DROP TABLE IF EXISTS `kliencibezzakupow`;
/*!50001 DROP VIEW IF EXISTS `kliencibezzakupow`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `kliencibezzakupow` AS SELECT 
 1 AS `IDKlient`,
 1 AS `Nazwa`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `pracownicytop5`
--

DROP TABLE IF EXISTS `pracownicytop5`;
/*!50001 DROP VIEW IF EXISTS `pracownicytop5`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `pracownicytop5` AS SELECT 
 1 AS `Imie`,
 1 AS `Nazwisko`,
 1 AS `DataZakupu`,
 1 AS `LiczbaSprzedazy`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `albumywartosci`
--

DROP TABLE IF EXISTS `albumywartosci`;
/*!50001 DROP VIEW IF EXISTS `albumywartosci`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `albumywartosci` AS SELECT 
 1 AS `Album`,
 1 AS `sumaWartosci`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `pracownicyfunkcje`
--

DROP TABLE IF EXISTS `pracownicyfunkcje`;
/*!50001 DROP VIEW IF EXISTS `pracownicyfunkcje`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `pracownicyfunkcje` AS SELECT 
 1 AS `Imie`,
 1 AS `nazwisko`,
 1 AS `FunkcjaNazwa`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `zakupypracownikow3plus`
--

/*!50001 DROP VIEW IF EXISTS `zakupypracownikow3plus`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `zakupypracownikow3plus` AS select `zakupywszystko`.`data zakupu` AS `data zakupu`,`zakupywszystko`.`Imię i nazwisko pracownika` AS `Imię i nazwisko pracownika`,`zakupywszystko`.`IDPracownik` AS `IDPracownik`,`zakupywszystko`.`funkcja pracownika` AS `funkcja pracownika`,`zakupywszystko`.`nazwa klienta` AS `nazwa klienta`,`zakupywszystko`.`NIP klienta` AS `NIP klienta`,`zakupywszystko`.`kod pocztowy` AS `kod pocztowy`,`zakupywszystko`.`Miasto` AS `Miasto`,`zakupywszystko`.`ulica, nr` AS `ulica, nr`,`zakupywszystko`.`Kategoria` AS `Kategoria`,`zakupywszystko`.`Wykonawca` AS `Wykonawca`,`zakupywszystko`.`Album` AS `Album`,`zakupywszystko`.`Gatunek` AS `Gatunek`,`zakupywszystko`.`ilość` AS `ilość`,`zakupywszystko`.`cena` AS `cena`,`zakupywszystko`.`wartość` AS `wartość` from `zakupywszystko` where `zakupywszystko`.`IDPracownik` in (select `zakupy`.`PracownikID` from `zakupy` group by `zakupy`.`PracownikID` having (count(0) >= 3)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `gatunkiwartosci`
--

/*!50001 DROP VIEW IF EXISTS `gatunkiwartosci`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `gatunkiwartosci` AS select `zakupywszystko`.`Gatunek` AS `Gatunek`,sum(`zakupywszystko`.`wartość`) AS `sumaWartosci` from `zakupywszystko` group by `zakupywszystko`.`Gatunek` order by `sumaWartosci` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `pracownicybezsprzedazy`
--

/*!50001 DROP VIEW IF EXISTS `pracownicybezsprzedazy`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `pracownicybezsprzedazy` AS select `p`.`Imie` AS `Imie`,`p`.`Nazwisko` AS `Nazwisko` from (`pracownicy` `p` left join `zakupy` `z` on((`p`.`IDPracownik` = `z`.`PracownikID`))) where (`z`.`IDZakup` is null) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `produktywszystko`
--

/*!50001 DROP VIEW IF EXISTS `produktywszystko`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `produktywszystko` AS select `p`.`Wykonawca` AS `Wykonawca`,`p`.`Album` AS `Album`,`p`.`DataPremiery` AS `DataPremiery`,`p`.`Cena` AS `Cena`,`k`.`Kategoria` AS `Kategoria`,`g`.`Gatunek` AS `Gatunek` from ((`produkty` `p` join `kategorie` `k` on((`p`.`KategoriaID` = `k`.`IDKategoria`))) left join `gatunki` `g` on((`p`.`GatunekID` = `g`.`IDGatunek`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `klienciliczbazakupow`
--

/*!50001 DROP VIEW IF EXISTS `klienciliczbazakupow`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `klienciliczbazakupow` AS select `zakupywszystko`.`nazwa klienta` AS `nazwa klienta`,count(0) AS `LiczbaZakupow` from `zakupywszystko` group by `zakupywszystko`.`nazwa klienta` order by `LiczbaZakupow` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `zakupywszystko`
--

/*!50001 DROP VIEW IF EXISTS `zakupywszystko`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `zakupywszystko` AS select `z`.`DataZakupu` AS `data zakupu`,concat(`p`.`Imie`,' ',`p`.`Nazwisko`) AS `Imię i nazwisko pracownika`,`p`.`IDPracownik` AS `IDPracownik`,`fp`.`FunkcjaNazwa` AS `funkcja pracownika`,`k`.`Nazwa` AS `nazwa klienta`,`k`.`NIP` AS `NIP klienta`,`k`.`KodPoczt` AS `kod pocztowy`,`k`.`Miasto` AS `Miasto`,`k`.`UlicaNr` AS `ulica, nr`,`kt`.`Kategoria` AS `Kategoria`,`pr`.`Wykonawca` AS `Wykonawca`,`pr`.`Album` AS `Album`,`g`.`Gatunek` AS `Gatunek`,`z`.`Ilosc` AS `ilość`,round(`pr`.`Cena`,2) AS `cena`,round((`z`.`Ilosc` * `pr`.`Cena`),2) AS `wartość` from (((((`zakupy` `z` left join (`pracownicy` `p` join `funkcjepracownikow` `fp` on((`p`.`FunkcjaID` = `fp`.`IDFunkcja`))) on((`z`.`PracownikID` = `p`.`IDPracownik`))) join `klienci` `k` on((`z`.`KlientID` = `k`.`IDKlient`))) join `produkty` `pr` on((`z`.`ProduktID` = `pr`.`IDProdukt`))) join `kategorie` `kt` on((`pr`.`KategoriaID` = `kt`.`IDKategoria`))) left join `gatunki` `g` on((`pr`.`GatunekID` = `g`.`IDGatunek`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `kliencibezzakupow`
--

/*!50001 DROP VIEW IF EXISTS `kliencibezzakupow`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `kliencibezzakupow` AS select `k`.`IDKlient` AS `IDKlient`,`k`.`Nazwa` AS `Nazwa` from (`klienci` `k` left join `zakupy` `z` on((`z`.`KlientID` = `k`.`IDKlient`))) where (`z`.`IDZakup` is null) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `pracownicytop5`
--

/*!50001 DROP VIEW IF EXISTS `pracownicytop5`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `pracownicytop5` AS select `p`.`Imie` AS `Imie`,`p`.`Nazwisko` AS `Nazwisko`,`z`.`DataZakupu` AS `DataZakupu`,count(0) AS `LiczbaSprzedazy` from (`zakupy` `z` join `pracownicy` `p` on((`z`.`PracownikID` = `p`.`IDPracownik`))) group by `p`.`Imie`,`p`.`Nazwisko`,`z`.`DataZakupu` order by `LiczbaSprzedazy` desc limit 5 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `albumywartosci`
--

/*!50001 DROP VIEW IF EXISTS `albumywartosci`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `albumywartosci` AS select `zakupywszystko`.`Album` AS `Album`,sum(`zakupywszystko`.`wartość`) AS `sumaWartosci` from `zakupywszystko` group by `zakupywszystko`.`Album` order by `sumaWartosci` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `pracownicyfunkcje`
--

/*!50001 DROP VIEW IF EXISTS `pracownicyfunkcje`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `pracownicyfunkcje` AS select `p`.`Imie` AS `Imie`,`p`.`Nazwisko` AS `nazwisko`,`f`.`FunkcjaNazwa` AS `FunkcjaNazwa` from (`pracownicy` `p` join `funkcjepracownikow` `f` on((`p`.`FunkcjaID` = `f`.`IDFunkcja`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Dumping events for database 'musicshop'
--

--
-- Dumping routines for database 'musicshop'
--
/*!50003 DROP FUNCTION IF EXISTS `liczbazakupowinternwdniu` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `liczbazakupowinternwdniu`(dataZakup DATE) RETURNS int
BEGIN

RETURN
(
		SELECT
			Count(*)
		FROM
			zakupy
		WHERE
			PracownikID IS NULL
            AND
            DataZakupu = dataZakup
);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `zakupypracownika` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `zakupypracownika`(prac NVARCHAR(255))
BEGIN
	SELECT
		*
	FROM
		zakupywszystko
	WHERE
		`Imię i nazwisko pracownika` LIKE CONCAT('%', prac, '%');
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-01-06 21:48:37
