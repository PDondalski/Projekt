SELECT
	  p.Imie
    , p.Nazwisko
FROM
	pracownicy p
    LEFT JOIN
    zakupy z
		ON p.IDPracownik = z.PracownikID
WHERE
	z.IDZakup IS NULL
