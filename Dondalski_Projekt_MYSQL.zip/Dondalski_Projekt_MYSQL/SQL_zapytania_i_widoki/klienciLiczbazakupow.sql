SELECT
	`nazwa klienta`
    , COUNT(*) AS LiczbaZakupow
FROM
	zakupywszystko
GROUP BY
	`nazwa klienta`
ORDER BY
	LiczbaZakupow DESC;

