SELECT
	Gatunek
    , SUM(wartość) AS sumaWartosci
FROM
	zakupywszystko
GROUP BY
	Gatunek
ORDER BY
	sumaWartosci DESC

