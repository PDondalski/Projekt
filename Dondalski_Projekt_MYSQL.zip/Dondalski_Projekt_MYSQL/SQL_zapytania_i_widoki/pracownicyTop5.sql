SELECT 
	  p.Imie
    , p.Nazwisko
    , z.DataZakupu
    , Count(*) AS LiczbaSprzedazy
FROM
	zakupy z
    INNER JOIN
    pracownicy p
		ON z.PracownikID = p.IDPracownik
GROUP BY
	p.Imie, p.Nazwisko, z.DataZakupu
ORDER BY
	LiczbaSprzedazy DESC
LIMIT 5;

