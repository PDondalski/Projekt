SELECT
	Wykonawca
    , Album
    , DataPremiery
    , Cena
    , Kategoria
    , Gatunek
FROM
	produkty p
    INNER JOIN
    kategorie k
		ON p.KategoriaID = k.IDKategoria
	LEFT JOIN
    gatunki g
		ON p.GatunekID = g.IDGatunek;