SELECT
	*
FROM
	zakupywszystko
WHERE
	IDPracownik IN
    (
		SELECT
			PracownikID
		FROM
			zakupy
		GROUP BY
			PracownikID
		HAVING
			Count(*) >= 3
    );
