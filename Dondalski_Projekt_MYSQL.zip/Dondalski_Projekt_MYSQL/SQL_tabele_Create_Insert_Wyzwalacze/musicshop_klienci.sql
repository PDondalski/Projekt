-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: musicshop
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `klienci`
--

DROP TABLE IF EXISTS `klienci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `klienci` (
  `IDKlient` int unsigned NOT NULL AUTO_INCREMENT,
  `Nazwa` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `NIP` varchar(10) DEFAULT NULL,
  `KodPoczt` varchar(6) DEFAULT NULL,
  `Miasto` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `UlicaNr` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`IDKlient`),
  UNIQUE KEY `IDKlient_UNIQUE` (`IDKlient`),
  KEY `iNazwa` (`Nazwa`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `klienci`
--

LOCK TABLES `klienci` WRITE;
/*!40000 ALTER TABLE `klienci` DISABLE KEYS */;
INSERT INTO `klienci` VALUES (1,'Arleta Mróz',NULL,'10-900','Olsztyn','ul. Klocowa 101'),(2,'DrutPol sp.z.o.o','1234567890','10-900','Olsztyn','ul. Balerona 11'),(3,'Wojciech Sosna',NULL,'10-900','Olsztyn','ul. Akacjowa 6'),(4,'Rafał Pacześ',NULL,'10-900','Olsztyn','ul. Ogrodowa 10'),(5,'Michał Grabara',NULL,'41-800','Zabrze','ul. Amarantowa 14'),(6,'Andrzej Romanowski',NULL,'41-819','Zabrze','ul. Franciszkanów 20'),(7,'Marzena Wykidajło',NULL,'32-020','Zabawka','ul. Jakubowa 16'),(8,'Przemysław Komandos',NULL,'51-625','Wolsztyn','ul. Kadłubowa 18'),(9,'DzwigareX sp.z.o.o','2136458790','50-500','Kadziszewo','ul. Gronostajowa 8'),(10,'Alicja Kalafior',NULL,'11-600','Trękucek','ul. Jedyna 1'),(11,'Weronika Biedronka',NULL,'17-500','Trebuszewo','ul. Brokatowa 5'),(12,'Maciej Sulej',NULL,'25-600','Spokojewo','ul. Spokojna 2'),(13,'Hektor Bonifacy',NULL,'11-500','Olsztynek','ul. Beznadziejna 14'),(14,'Fifonż Kaznodzieja',NULL,'10-900','Olsztyn','ul. Szokowczyka 5'),(15,'Czarek Lebiega',NULL,'10-900','Olsztyn','ul. Testowa 25'),(16,'Stanisław Markowski',NULL,'10-900','Olsztyn','ul. Prosta 11/B'),(17,'Piotr Dondalski',NULL,'10-900','Olsztyn','ul. Granatowa 48/A'),(18,'Kamil Garbarczyk',NULL,'10-900','Olsztyn','ul. Biała 5'),(19,'Paweł Nowak',NULL,'10-900','Olsztyn','ul. Kwiatowa 12 b/7'),(20,'Wojciech Zawada',NULL,'10-900','Olsztyn','Plac Zawiszy 1000/b');
/*!40000 ALTER TABLE `klienci` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-01-06 21:48:36
