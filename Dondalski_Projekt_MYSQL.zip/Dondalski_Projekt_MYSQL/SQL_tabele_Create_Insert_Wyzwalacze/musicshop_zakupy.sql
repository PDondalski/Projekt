-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: musicshop
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `zakupy`
--

DROP TABLE IF EXISTS `zakupy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `zakupy` (
  `IDZakup` int unsigned NOT NULL AUTO_INCREMENT,
  `ProduktID` int unsigned NOT NULL,
  `PracownikID` int unsigned DEFAULT NULL,
  `KlientID` int unsigned NOT NULL,
  `DataZakupu` date NOT NULL,
  `Ilosc` smallint NOT NULL DEFAULT '1',
  PRIMARY KEY (`IDZakup`),
  UNIQUE KEY `IDZakup_UNIQUE` (`IDZakup`),
  KEY `iProduktID` (`ProduktID`) /*!80000 INVISIBLE */,
  KEY `iKlientID` (`KlientID`) /*!80000 INVISIBLE */,
  KEY `FKPracownik_idx` (`PracownikID`),
  CONSTRAINT `FKKlient` FOREIGN KEY (`KlientID`) REFERENCES `klienci` (`IDKlient`) ON UPDATE CASCADE,
  CONSTRAINT `FKPracownik` FOREIGN KEY (`PracownikID`) REFERENCES `pracownicy` (`IDPracownik`),
  CONSTRAINT `FKProdukt` FOREIGN KEY (`ProduktID`) REFERENCES `produkty` (`IDProdukt`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zakupy`
--

LOCK TABLES `zakupy` WRITE;
/*!40000 ALTER TABLE `zakupy` DISABLE KEYS */;
INSERT INTO `zakupy` VALUES (3,1,NULL,17,'2021-01-05',2),(4,4,2,3,'2021-01-05',1),(5,2,1,14,'2021-01-05',1),(6,10,NULL,11,'2021-01-05',2),(7,15,NULL,9,'2021-01-06',1),(8,17,NULL,6,'2021-01-06',1),(9,7,1,11,'2021-01-06',2),(10,5,4,9,'2021-01-07',1),(11,9,3,19,'2021-01-07',1),(12,12,3,12,'2021-01-08',1),(13,18,NULL,20,'2021-01-08',2),(14,16,4,14,'2021-01-09',1),(15,8,1,10,'2021-01-09',2),(16,16,1,13,'2021-01-09',3),(17,6,3,15,'2021-01-10',2),(18,6,3,12,'2021-01-11',3),(19,18,NULL,17,'2021-01-11',1),(20,14,NULL,20,'2021-01-11',5),(21,3,4,16,'2021-01-12',1),(22,9,4,19,'2021-01-13',2),(23,13,NULL,18,'2021-01-13',4),(24,18,NULL,17,'2021-01-14',3);
/*!40000 ALTER TABLE `zakupy` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `zakupy_AFTER_INSERT` AFTER INSERT ON `zakupy` FOR EACH ROW BEGIN
INSERT INTO musicshop.log
(Czas,Tabela,Operacja,Uzytkownik,RekordID)
VALUES
(
NOW()
,'zakupy'
,'dodanie'
, current_user()
, new.IDZakup
);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `zakupy_AFTER_UPDATE` AFTER UPDATE ON `zakupy` FOR EACH ROW BEGIN
INSERT INTO musicshop.log
(Czas,Tabela,Operacja,Uzytkownik,RekordID)
VALUES
(
NOW()
,'zakupy'
,'modyfikacja'
, current_user()
, new.IDZakup
);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `zakupy_AFTER_DELETE` AFTER DELETE ON `zakupy` FOR EACH ROW BEGIN
INSERT INTO musicshop.log
(Czas,Tabela,Operacja,Uzytkownik,RekordID)
VALUES
(
NOW()
,'zakupy'
,'usuniecie'
, current_user()
, old.IDZakup
);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-01-06 21:48:36
