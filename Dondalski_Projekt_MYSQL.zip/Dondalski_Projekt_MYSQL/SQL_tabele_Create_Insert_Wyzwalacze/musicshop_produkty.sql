-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: musicshop
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `produkty`
--

DROP TABLE IF EXISTS `produkty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produkty` (
  `IDProdukt` int unsigned NOT NULL AUTO_INCREMENT,
  `GatunekID` smallint unsigned DEFAULT NULL,
  `KategoriaID` smallint unsigned NOT NULL,
  `Wykonawca` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Album` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `DataPremiery` date DEFAULT NULL,
  `Cena` decimal(9,4) unsigned NOT NULL,
  PRIMARY KEY (`IDProdukt`),
  UNIQUE KEY `IDProdukt_UNIQUE` (`IDProdukt`),
  KEY `FKGatunek_idx` (`GatunekID`),
  KEY `FKKategoria_idx` (`KategoriaID`),
  CONSTRAINT `FKGatunek` FOREIGN KEY (`GatunekID`) REFERENCES `gatunki` (`IDGatunek`) ON UPDATE CASCADE,
  CONSTRAINT `FKKategoria` FOREIGN KEY (`KategoriaID`) REFERENCES `kategorie` (`IDKategoria`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produkty`
--

LOCK TABLES `produkty` WRITE;
/*!40000 ALTER TABLE `produkty` DISABLE KEYS */;
INSERT INTO `produkty` VALUES (1,1,1,'WWO','Życie na kredycie','2013-04-15',31.9900),(2,1,1,'Słoń','REDRUM','2020-12-17',39.9900),(3,1,3,'WWO','Masz i pomyśl','2000-09-14',40.0000),(4,1,3,'MADBALL','Set it off','1994-07-26',53.8900),(5,1,1,'Quebonafide','Romantic Psycho','2020-04-01',40.9900),(6,1,1,'Guzior','Pleśń','2020-12-04',44.9900),(7,3,1,'Apocalyptica','Cell-0','2020-01-10',54.8300),(8,3,1,'Apocalyptica','Reflections','2003-10-02',68.9900),(9,4,1,'ACDC','Rock or Bust','2014-11-28',32.0900),(10,4,2,'ACDC','High Voltage LP','2009-05-11',99.9900),(11,4,3,'Scorpions','Crazy World','1990-10-06',35.9900),(12,NULL,2,'Czesław Niemen','The Best of Niemen','2018-10-13',75.9900),(13,2,2,'Krzysztof Krawczyk','Horyzont','2020-11-27',66.9300),(14,5,1,'Enej','Folkorabel','2010-10-12',31.9900),(15,5,1,'Enej','Folkhorod','2012-10-16',31.9900),(16,2,1,'Pink','Funhouse','2008-10-29',44.0600),(17,6,1,'Leonard Cohen','You Want It Darker','2016-10-21',36.5200),(18,2,1,'Michał Bajor','Uczucia','1998-12-31',27.9900);
/*!40000 ALTER TABLE `produkty` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-01-06 21:48:36
