DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `zakupypracownika`(prac NVARCHAR(255))
BEGIN
	SELECT
		*
	FROM
		zakupywszystko
	WHERE
		`Imię i nazwisko pracownika` LIKE CONCAT('%', prac, '%');
END$$
DELIMITER ;

