DELIMITER $$
CREATE DEFINER=`root`@`localhost` FUNCTION `liczbazakupowinternwdniu`(dataZakup DATE) RETURNS int
BEGIN

RETURN
(
		SELECT
			Count(*)
		FROM
			zakupy
		WHERE
			PracownikID IS NULL
            AND
            DataZakupu = dataZakup
);
END $$
DELIMITER ;
